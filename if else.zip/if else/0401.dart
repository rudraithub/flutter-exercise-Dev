void main(){
  int number= 10;
  if (number>5);{
 print("The number is greater than 5.");
  }
}