void main() {
  int number = 10;
 if (number%2 == 0) {
    print('$number is even');
  } else {
    print('$number is odd');
  }
}