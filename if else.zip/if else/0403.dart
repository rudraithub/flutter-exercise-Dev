void main(){
  int num1= 10;
  int num2= 10;
  if(num1==num2);{
    print("The numbers are equal.");
  }

}