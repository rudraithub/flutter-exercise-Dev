void main(){
 var a= 23;
  if(a<0){
    print("Given number is negative.");
  }
  else if(a==0){
    print("Given number is Zero.");
 }
 else{
  print("Given number is Positive.");
 }
}