void main(){
  String text= 'Hello';
  if (text.isNotEmpty);{
    print("The text is not empty.");
  }
}