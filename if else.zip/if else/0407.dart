void main(){
  int a= 55;
  if(a%5==0 && a%11==0){
     print("Number is divisible by both 5 and 11.");
  }
else{
  print("Number is not divisible by both 5 and 11.");
}
}