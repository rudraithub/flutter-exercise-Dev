void main(){
  int year= 2004;
  if(year%4==0){
    print("2004 is leap year.");
  }
  else{
    print("2004 is not leap year");
  }
}