void main(){
  int a= 56;
  int b= 80;
 print(a+b);
 print(a-b);
 print(a*b);
 print(a/b);
 print(a%b);

}