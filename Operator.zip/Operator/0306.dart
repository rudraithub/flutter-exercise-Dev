void main (){
  int x= 22;
  int y= 39;
  print(x+y);
  print(x-y);
  print(x/y);
  print(x*y);
  print(x~/y);
  print(x%y);
}