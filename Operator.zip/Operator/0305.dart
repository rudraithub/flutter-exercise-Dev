void main(){
  int a=25;
  int b= 8;
  a+=b;
  print(a);
  a-=b;
  print(a);
  a*=b;
  print(a);
  a%=b;
  print(a);

 
}