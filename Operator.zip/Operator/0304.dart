void main(){
  int a=99;
  int b=12;
  print("Value of c is ${a+b}");
  print("Value of c is ${a-b}");
  print("Value of c is ${a*b}");
  print("Value of c is ${a/b}");
  print("Value of c is ${a%b}");



}