void main (){
   int a=52;
  int b=45;
   a+=b;
   print(a);
  
 
}