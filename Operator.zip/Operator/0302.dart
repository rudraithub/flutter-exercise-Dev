void main(){
  int x=12;
  int y= 20;
  print("x is less than and equal to y: ${x<=y}");
  print("x is less than y: ${x<y}");
  print("x is greater than y: ${x>y}");
  print("x is greater than and equal to y: ${x>=y}");
  print("x is equal to y: ${x==y}");
  print("x is not equal to y :${x!=y}");
  print(x<=y);
}