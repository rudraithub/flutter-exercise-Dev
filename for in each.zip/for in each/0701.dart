void main(){
  List<String> a= ['one','Two','Three'];
 for (var b in a) {
   print(b);
 }
}