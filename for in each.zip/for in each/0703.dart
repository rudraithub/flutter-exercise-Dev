void main(){
  List<String> a= ['Ronaldo','Messi','Neymar','Hazard'];
 for (var b in a) {
   print(b);
 }
}