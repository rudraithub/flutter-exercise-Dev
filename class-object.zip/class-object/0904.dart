void main(){
  var obj=School();
 print(obj.name);
 print(obj.area);
print(obj.ownername);
 print(obj.schlrank);
}
class School{
  String name= 'Pratik Mehta';
   String area  = 'Sagwadi';
  String ownername = 'Manharbhai Rathod';
 int schlrank= 2;
}