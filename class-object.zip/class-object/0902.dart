void main(){
 var obj=Employee();
 print(obj.name);
 print(obj.mobno);
print(obj.salary);
 print(obj.cmpnyname);
}
class Employee{
 
  
  String name= 'Pratik Mehta';
   int mobno = 9988123458;
  int salary = 10000;
  String cmpnyname= 'Aptizech';
  
    
  }