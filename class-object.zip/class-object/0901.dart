

void main(){
 var obj=A();
 print(obj.rollno);
 print(obj.name);
 //print(obj.DOB);
 print(obj.mobno);
 print(obj.city);
}
class A{
 
  int rollno = 1;
  String name= 'Mahi Patel';
  //int DOB= 01.01.2002;
  int mobno = 9999999999;
  String city=  'Bhavnagar';
  
    
  }

