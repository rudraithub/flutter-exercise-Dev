void main(){
var obj= Bank();
print(obj.bnkname);
print(obj.brnchname);
print(obj.accno);
print(obj.ctynme);
}

class Bank{
  String bnkname= 'HDFC';
  String brnchname= 'Avenue road';
  int accno= 364011223387;
  String ctynme= 'Banglore';
}