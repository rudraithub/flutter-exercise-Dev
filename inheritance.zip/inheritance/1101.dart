void main(){
A obj= B();
obj.display();
print(obj.a);
print(obj.b);
}

class A{
  int a= 999;
  int b= 898;
  void display(){
   
  }
  }

  class B extends A{
    void display(){

    }
  }