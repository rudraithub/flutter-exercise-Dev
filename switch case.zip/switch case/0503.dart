void main(){
  int a= 12;
  switch (a%2) {
    case 0:
    {
      print("The given number is Even.");
    }
     break;
     case 1:
     {
      print("The given number is Odd.");
     }
    default:
  }
}