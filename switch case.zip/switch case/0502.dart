

void main(){
  int a= 12;
  int b= 40;
  var c= a>b;
switch (c) {
    case true:
    {
      print("Here Maximum number is 20");
    }
  
      default:{
        print('Here maximum number is 40');
      }
    } 
  }