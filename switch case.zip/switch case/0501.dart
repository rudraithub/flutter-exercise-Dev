void main(){
  int a= 23;
  switch (a) {
    case <0:
    {
      print("Given number is Negative");
    }
    break;
    case 0:
    {
      print("Given number is Zero.");
    }
    break;
    case >0:
    {
      print("Given number is Positive.");
    }
    default:
  }
}