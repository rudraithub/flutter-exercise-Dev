08

void main() {
 String B = "WELCOME TO RUDRA IT HUB";
  print(B.toLowerCase());
}
