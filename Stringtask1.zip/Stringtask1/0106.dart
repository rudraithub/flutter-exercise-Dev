void main(){
    String a= "Rudra";
    print(a.split("").reversed.join());
}
