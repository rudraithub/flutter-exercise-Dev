void main(){
  String a= 'This is Rudra IT Hub.';
    
     print(a.split(' ').length);


}