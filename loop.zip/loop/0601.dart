void main(){
  for (int i=1; i<11; i++)
  {
    print(i);
  }
  
}