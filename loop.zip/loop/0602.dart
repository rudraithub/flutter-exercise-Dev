void main(){
  for (int i=10; i>0; i--){
    print(i);
  }
}