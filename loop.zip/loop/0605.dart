void main(){
  for (int i=1; i<11; i++){
    print("5 * $i= ${5*i}");
  }
}